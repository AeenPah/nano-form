just read me
